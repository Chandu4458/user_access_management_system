package useraccessmanagement;

public @interface WebServlet {

}
